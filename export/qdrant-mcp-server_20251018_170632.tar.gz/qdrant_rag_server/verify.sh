#!/bin/bash
echo "🔍 Verificando instalação..."

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado"
    exit 1
fi

# Verificar pip
if ! command -v pip &> /dev/null; then
    echo "❌ pip não encontrado"
    exit 1
fi

# Verificar Qdrant
if ! curl -s http://localhost:6333/health > /dev/null; then
    echo "❌ Qdrant não está rodando em localhost:6333"
    echo "   Inicie com: docker run -p 6333:6333 qdrant/qdrant"
    exit 1
fi

echo "✅ Tudo ok! Pronto para usar."
