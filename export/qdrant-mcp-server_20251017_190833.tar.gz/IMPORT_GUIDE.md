# 📦 MCP Qdrant Server - Guia de Importação

## 🚀 Como usar em outro projeto

### Passo 1: Extrair o arquivo
```bash
tar -xzf qdrant-mcp-server_*.tar.gz
```

### Passo 2: Copiar para seu projeto
```bash
cp -r qdrant_rag_server /seu/projeto/mcp/
```

### Passo 3: Configurar variáveis de ambiente
```bash
cd /seu/projeto/mcp/qdrant_rag_server
cp .env.example .env
# Editar .env com suas configurações
```

### Passo 4: Instalar dependências
```bash
# CPU-only (recomendado)
pip install -r requirements.txt
pip install -r requirements-fastembed.txt

# OU com GPU
pip install -r requirements.txt
pip install -r requirements-sentencetransformers.txt

# OU com OpenAI
pip install -r requirements.txt
pip install -r requirements-openai.txt
```

### Passo 5: Inicializar banco de dados
```bash
python3 mcp/qdrant_rag_server/qdrant_create_db.py
```

### Passo 6: Iniciar MCP Server
```bash
# Simples
python3 mcp/qdrant_rag_server/server.py

# Ou com daemon wrapper
bash mcp/qdrant_rag_server/start-daemon.sh
```

## 📋 Checklist de Compatibilidade

- ✅ Python 3.8+ (recomendado 3.10+)
- ✅ Qdrant rodando (Docker ou local)
- ✅ pip disponível
- ✅ Porta 6333 disponível (Qdrant)
- ✅ ~/.continue/config.json configurado (para VS Code)

## ⚙️ Configuração Essencial (.env)

```ini
# Qdrant
QDRANT_URL=http://localhost:6333
QDRANT_API_KEY=seu-api-key-aqui
QDRANT_COLLECTION=seu-collection-name

# Embeddings
EMBEDDINGS_PROVIDER=fastembed
MODEL_NAME=BAAI/bge-small-en-v1.5
VECTOR_SIZE=384
DISTANCE=COSINE
```

## 🔌 Integração com Continue (VS Code)

Editar `~/.continue/config.json`:

```json
{
  "mcpServers": {
    "seu-projeto-mcp": {
      "command": "bash",
      "args": [
        "-c",
        "cd /seu/projeto && python3 mcp/qdrant_rag_server/server.py"
      ]
    }
  }
}
```

## 📁 Estrutura esperada no seu projeto

```
/seu/projeto/
├── mcp/
│   └── qdrant_rag_server/
│       ├── server.py
│       ├── qdrant_create_db.py
│       ├── .env
│       ├── requirements.txt
│       └── ...
└── ...
```

## 🆘 Troubleshooting

### Erro: "qdrant_client not found"
```bash
pip install -r mcp/qdrant_rag_server/requirements.txt
```

### Erro: "Cannot connect to Qdrant"
```bash
# Verificar se Qdrant está rodando
docker ps | grep qdrant
# Ou iniciar Qdrant
docker-compose up -d qdrant
```

### Erro: "FastEmbed model not found"
```bash
pip install -r mcp/qdrant_rag_server/requirements-fastembed.txt
```

## ✅ Testes rápidos

### Testar importação de módulos
```bash
python3 -c "from qdrant_client import QdrantClient; print('✅ OK')"
```

### Testar MCP Server
```bash
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | \
  python3 mcp/qdrant_rag_server/server.py
```

### Testar conexão Qdrant
```bash
curl http://localhost:6333/collections
```

## 📞 Suporte

Verifique os arquivos:
- `README.md` - Documentação detalhada
- `server.py` - Código comentado
- `.env.example` - Template de configuração

---

**Pronto para usar em qualquer projeto!** 🚀
