#!/bin/bash
cd /home/yves_marinho/Documentos/DevOps/Projetos/ai_project_template
exec /home/yves_marinho/Documentos/DevOps/Projetos/ai_project_template/.venv/bin/python3 mcp/qdrant_rag_server/server.py
