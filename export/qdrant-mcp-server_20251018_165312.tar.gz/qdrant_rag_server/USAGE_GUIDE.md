# 🚀 Guia de Uso - MCP Qdrant Server

## 📦 Como usar este pacote em seu projeto

### 🎯 Passo 1: Copiar para seu projeto

```bash
# Copiar para seu projeto
cp -r qdrant_rag_server /caminho/para/seu/projeto/mcp/
```

### ⚙️ Passo 2: Configurar

```bash
cd /seu/projeto/mcp/qdrant_rag_server

# Criar configuração
cp .env.example .env
nano .env  # Editar conforme necessário
```

### 📦 Passo 3: Instalar dependências

```bash
pip install -r requirements.txt
pip install -r requirements-fastembed.txt  # Para CPU-only
```

### 🚀 Passo 4: Executar

```bash
# Tornar scripts executáveis
chmod +x *.sh

# Criar coleção no Qdrant
python3 qdrant_create_db.py

# Iniciar servidor MCP
./start-daemon-bg.sh

# Verificar status
./status-daemon.sh
```

### 🔗 Passo 5: Configurar VS Code

Adicionar em `~/.continue/config.json`:

```json
{
  "mcpServers": {
    "meu-projeto-rag": {
      "command": "python3",
      "args": ["/caminho/absoluto/para/seu/projeto/mcp/qdrant_rag_server/server.py"],
      "env": {
        "QDRANT_URL": "http://localhost:6333",
        "QDRANT_COLLECTION": "meu_projeto_docs"
      }
    }
  }
}
```

## 📁 Estrutura final esperada

```
seu_projeto/
├── src/                    ← Seu código
├── docs/                   ← Sua documentação
├── mcp/                    ← Pasta MCP
│   └── qdrant_rag_server/  ← Este pacote
│       ├── server.py
│       ├── .env
│       ├── start-daemon-bg.sh
│       └── ...
└── README.md               ← Seu README
```

## ✅ Verificação rápida

```bash
# Qdrant rodando?
curl http://localhost:6333/health

# Servidor MCP ativo?
./status-daemon.sh

# Testar ferramenta
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' | python3 server.py
```

---

**🎯 Pronto! Agora você tem busca semântica no seu projeto.**
